#!/bin/bash


input_file=$1
csv_file="resultat.csv"


docker run -d --name excel2csv-container bigpapoo/sae103-excel2csv tail -f /dev/null
docker cp ./"Tableau des médailles v2.xlsx" excel2csv-container:/data
docker exec excel2csv-container ssconvert /data/"Tableau des médailles v2.xlsx" /data/resultat.csv
docker cp excel2csv-container:/data/resultat.csv resultat.csv


# Sort the CSV file based on multiple criteria:
# 1. Gold medals (descending)
# 2. Silver medals (descending)
# 3. Bronze medals (descending)
# 4. Country name (ascending)
# Then add ranking with dash
awk -F',' 'NR>1 {print $0}' "$csv_file" |
   sort -t',' -k2,2nr -k3,3nr -k4,4nr -k1,1 |
   awk -F',' '{
       if (NR == 1) {
           prev = $0
           rank = 1
           print rank " - " $0
           rank++

       } else {
           split(prev, a, ",")
           split($0, b, ",")
           if (a[2] == b[2] && a[3] == b[3] && a[4] == b[4]) {
               print "  " " - " $0
           } else {
               print rank " - " $0
           }
           rank++
           prev = $0
       }
   }' |
   sed '$d' |
   sed '$d' > "fichier_$csv_file"


#écriture du fichier html
 echo "
 <!DOCTYPE html>
 <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>
  <meta charset="utf-8" />
  <title>Résultat JO2024</title>
  <meta name="auhor" content="Keraudren Johan" />
  <meta name="description" content="" />
  <meta name="keywords" content="" />
  <style>
      body {
          font-family: Arial, sans-serif;
          margin: 20px;
      }
      header {
          text-align: center;
          margin-bottom: 20px;
      }
      table {
          width: 100%;
          border-collapse: collapse;
          margin: 0 auto;
      }
      th, td {
          border: 1px solid #000;
          padding: 5px;
          text-align: center;
      }
      th {
          background-color: #f3f3f3;
      }
      img.flag {
          width: 20px;
          height: auto;
      }
  </style>

</head>
<body>
    <table>
        <thead>
            <tr>
                <th> Drapeau </th>
                <th> Classement </th>
                <th> Pays </th>
                <th> OR </th>
                <th> ARGENT </th>
                <th> BRONZE </th>
            <tr>
        <thead>
        <tbody>
" >> Tableau2html.html;


while IFS=',' read -r classement pays or argent bronze
do
    echo "
        <tr>
            <td><img src="flags/${pays}.png" width="16" height="12" alt="${pays}">  </td>
            <td>$classement</td>
            <td>$pays</td>
            <td>$or</td>
            <td>$argent</td>
            <td>$bronze</td>
        </tr>" >> Tableau2html.html
done < "fichier_$csv_file"
echo "</tbody>
    </table>
</body>
</html>
" >> Tableau2html.html
docker rm -f excel2csv-container